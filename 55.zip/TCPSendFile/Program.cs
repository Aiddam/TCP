﻿using System;
using System.IO;
using System.Net;
using System.Net.Sockets;

public class TcpFileServer
{
    public static void Main()
    {
        int port = 5000;
        string fileToSend = "\"C:\\Users\\Антон\\Downloads\\BackgroundGC.png\"";
        string filePath = fileToSend;

        TcpListener server = new TcpListener(IPAddress.Any, port);
        server.Start();

        Console.WriteLine($"TCP-сервер запущено на порту {port}. Чекаємо на підключення...");

        while (true)
        {
            using (TcpClient client = server.AcceptTcpClient())
            {
                Console.WriteLine("Клієнт підключився. Відправляємо файл...");

                using (NetworkStream networkStream = client.GetStream())
                {
                    if (File.Exists(filePath))
                    {
                        byte[] fileData = File.ReadAllBytes(filePath);
                        networkStream.Write(fileData, 0, fileData.Length);
                        Console.WriteLine($"Файл {fileToSend} відправлено клієнту.");
                    }
                    else
                    {
                        Console.WriteLine($"Файл {fileToSend} не знайдено.");
                    }
                }
            }
        }
    }
}
