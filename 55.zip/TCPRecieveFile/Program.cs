﻿using System;
using System.IO;
using System.Net.Sockets;

public class TcpFileClient
{
    public static void Main()
    {
        string serverIp = "192.168.31.34"; // IP-адреса сервера
        int port = 5000;
        string receivedFileName = "received_file.txt";

        using (TcpClient client = new TcpClient(serverIp, port))
        {
            Console.WriteLine("Підключено до сервера. Отримуємо файл...");

            using (NetworkStream networkStream = client.GetStream())
            {
                using (FileStream fileStream = new FileStream(receivedFileName, FileMode.Create))
                {
                    byte[] buffer = new byte[4096];
                    int bytesRead;

                    while ((bytesRead = networkStream.Read(buffer, 0, buffer.Length)) > 0)
                    {
                        fileStream.Write(buffer, 0, bytesRead);
                    }

                    Console.WriteLine($"Файл отримано та збережено як {receivedFileName}.");
                }
            }
        }
    }
}
